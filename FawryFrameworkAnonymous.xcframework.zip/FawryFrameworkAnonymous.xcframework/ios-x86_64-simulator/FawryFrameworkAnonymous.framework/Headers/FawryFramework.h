//
//  FawryFramework.h
//  FawryFramework
//
//  Created by Ankit Goyal on 2020/12/27.
//  Copyright © 2020 Applify Tech Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FawryFramework.
FOUNDATION_EXPORT double FawryFrameworkVersionNumber;

//! Project version string for FawryFramework.
FOUNDATION_EXPORT const unsigned char FawryFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FawryFramework/PublicHeader.h>


